---
layout: page
title: Downloads
published: true
---

# Downloads


## Planet

Download entire planet as MBTiles:

- [Latest planet (40GB)]()

## Country Extracts

All country extracts consist of the world down to zoom level 6
and the entire country down to zoom level 14.

- [Afghanistan (2GB)]()
- [Albania (2GB)]()
- [Algeria (1.2GB)]()
- [Andorras (4GB)]()
- [Angola (2GB)]()
- [Argentina (0.5GB)]()
- [Armenia (0.2GB)]()
- [Austria (1GB)]()
- [Bahamas (2.2GB)]()
- [Bahrain (2.4GB)]()
- [Bangladesh (2.1GB)]()
- [Belarus (2.2GB)]()
- [Belgium (2.8GB)]()
